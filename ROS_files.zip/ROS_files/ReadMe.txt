put the full_description and movit_created folders in your catkin_ws/src folder.
Then create and source your workspace using catkin_make and source devel/bashrc commands.
Finally use Roslaunch movit_created full_robot_arm_sim.launch commands to bring up rviz with moveit controller and gazebo simultainously